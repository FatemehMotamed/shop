import bindStorage from 'nuxt-vuex-localstorage/plugins/bindStorage'

export default (ctx) => {
  const options = {"localStorage":["username","token","expire"],"sessionStorage":["sfoo"]}
  bindStorage(ctx, options)
}
