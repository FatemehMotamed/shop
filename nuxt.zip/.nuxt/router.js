import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from '@nuxt/ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _519e382f = () => interopDefault(import('../pages/about/index.vue' /* webpackChunkName: "pages/about/index" */))
const _12d1fd00 = () => interopDefault(import('../pages/brands/index.vue' /* webpackChunkName: "pages/brands/index" */))
const _292b8742 = () => interopDefault(import('../pages/contact/index.vue' /* webpackChunkName: "pages/contact/index" */))
const _c7b03214 = () => interopDefault(import('../pages/dashboard/index.vue' /* webpackChunkName: "pages/dashboard/index" */))
const _159b3162 = () => interopDefault(import('../pages/gifts.vue' /* webpackChunkName: "pages/gifts" */))
const _e9d7cbde = () => interopDefault(import('../pages/index2.vue' /* webpackChunkName: "pages/index2" */))
const _54bd9db9 = () => interopDefault(import('../pages/inspire.vue' /* webpackChunkName: "pages/inspire" */))
const _5886e10b = () => interopDefault(import('../pages/login/index.vue' /* webpackChunkName: "pages/login/index" */))
const _76868d5e = () => interopDefault(import('../pages/product/index.vue' /* webpackChunkName: "pages/product/index" */))
const _41e8af50 = () => interopDefault(import('../pages/products/index.vue' /* webpackChunkName: "pages/products/index" */))
const _33a754ea = () => interopDefault(import('../pages/profile/index.vue' /* webpackChunkName: "pages/profile/index" */))
const _0ef3c2d7 = () => interopDefault(import('../pages/register/index.vue' /* webpackChunkName: "pages/register/index" */))
const _70d34643 = () => interopDefault(import('../pages/test.vue' /* webpackChunkName: "pages/test" */))
const _924e9d20 = () => interopDefault(import('../pages/dashboard/branch/create/index.vue' /* webpackChunkName: "pages/dashboard/branch/create/index" */))
const _848cead8 = () => interopDefault(import('../pages/dashboard/category/create/index.vue' /* webpackChunkName: "pages/dashboard/category/create/index" */))
const _794605ee = () => interopDefault(import('../pages/dashboard/category/read/index.vue' /* webpackChunkName: "pages/dashboard/category/read/index" */))
const _0b7b0eee = () => interopDefault(import('../pages/dashboard/products/create/index.vue' /* webpackChunkName: "pages/dashboard/products/create/index" */))
const _7bcafd9c = () => interopDefault(import('../pages/dashboard/users/create/index.vue' /* webpackChunkName: "pages/dashboard/users/create/index" */))
const _4fb23914 = () => interopDefault(import('../pages/dashboard/users/list/index.vue' /* webpackChunkName: "pages/dashboard/users/list/index" */))
const _da8a186e = () => interopDefault(import('../pages/dashboard/users/login/index.vue' /* webpackChunkName: "pages/dashboard/users/login/index" */))
const _865ad9ae = () => interopDefault(import('../pages/dashboard/branch/edit/_id/index.vue' /* webpackChunkName: "pages/dashboard/branch/edit/_id/index" */))
const _02410b2a = () => interopDefault(import('../pages/dashboard/users/edit/_id/index.vue' /* webpackChunkName: "pages/dashboard/users/edit/_id/index" */))
const _7b29851e = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about",
    component: _519e382f,
    name: "about"
  }, {
    path: "/brands",
    component: _12d1fd00,
    name: "brands"
  }, {
    path: "/contact",
    component: _292b8742,
    name: "contact"
  }, {
    path: "/dashboard",
    component: _c7b03214,
    name: "dashboard"
  }, {
    path: "/gifts",
    component: _159b3162,
    name: "gifts"
  }, {
    path: "/index2",
    component: _e9d7cbde,
    name: "index2"
  }, {
    path: "/inspire",
    component: _54bd9db9,
    name: "inspire"
  }, {
    path: "/login",
    component: _5886e10b,
    name: "login"
  }, {
    path: "/product",
    component: _76868d5e,
    name: "product"
  }, {
    path: "/products",
    component: _41e8af50,
    name: "products"
  }, {
    path: "/profile",
    component: _33a754ea,
    name: "profile"
  }, {
    path: "/register",
    component: _0ef3c2d7,
    name: "register"
  }, {
    path: "/test",
    component: _70d34643,
    name: "test"
  }, {
    path: "/dashboard/branch/create",
    component: _924e9d20,
    name: "dashboard-branch-create"
  }, {
    path: "/dashboard/category/create",
    component: _848cead8,
    name: "dashboard-category-create"
  }, {
    path: "/dashboard/category/read",
    component: _794605ee,
    name: "dashboard-category-read"
  }, {
    path: "/dashboard/products/create",
    component: _0b7b0eee,
    name: "dashboard-products-create"
  }, {
    path: "/dashboard/users/create",
    component: _7bcafd9c,
    name: "dashboard-users-create"
  }, {
    path: "/dashboard/users/list",
    component: _4fb23914,
    name: "dashboard-users-list"
  }, {
    path: "/dashboard/users/login",
    component: _da8a186e,
    name: "dashboard-users-login"
  }, {
    path: "/dashboard/branch/edit/:id",
    component: _865ad9ae,
    name: "dashboard-branch-edit-id"
  }, {
    path: "/dashboard/users/edit/:id",
    component: _02410b2a,
    name: "dashboard-users-edit-id"
  }, {
    path: "/",
    component: _7b29851e,
    name: "index"
  }],

  fallback: false
}

function decodeObj(obj) {
  for (const key in obj) {
    if (typeof obj[key] === 'string') {
      obj[key] = decode(obj[key])
    }
  }
}

export function createRouter () {
  const router = new Router(routerOptions)

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    const r = resolve(to, current, append)
    if (r && r.resolved && r.resolved.query) {
      decodeObj(r.resolved.query)
    }
    return r
  }

  return router
}
