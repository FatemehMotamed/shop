const middleware = {}

middleware['authDashboard'] = require('../middleware/authDashboard.js')
middleware['authDashboard'] = middleware['authDashboard'].default || middleware['authDashboard']

middleware['authUser'] = require('../middleware/authUser.js')
middleware['authUser'] = middleware['authUser'].default || middleware['authUser']

middleware['guest'] = require('../middleware/guest.js')
middleware['guest'] = middleware['guest'].default || middleware['guest']

export default middleware
