export { default as VuetifyLogo } from '../../components/VuetifyLogo.vue'
export { default as BestBrands } from '../../components/app/Brands/BestBrands.vue'
export { default as BrandAlphabet } from '../../components/app/Brands/BrandAlphabet.vue'
export { default as BrandInfo } from '../../components/app/Brands/BrandInfo.vue'
export { default as BrandPagePic } from '../../components/app/Brands/BrandPagePic.vue'
export { default as PopularBrands } from '../../components/app/Brands/PopularBrands.vue'
export { default as SearchBrand } from '../../components/app/Brands/SearchBrand.vue'
export { default as Table } from '../../components/app/Dashboard/Table.vue'
export { default as FooterPage } from '../../components/app/Footer/FooterPage.vue'
export { default as FooterProduct } from '../../components/app/Footer/FooterProduct.vue'
export { default as Logo } from '../../components/app/Header/Logo.vue'
export { default as Logo2 } from '../../components/app/Header/Logo2.vue'
export { default as NavPage } from '../../components/app/Header/NavPage.vue'
export { default as NavPage2 } from '../../components/app/Header/NavPage2.vue'
export { default as SubNav } from '../../components/app/Header/SubNav.vue'
export { default as HomePage } from '../../components/app/Home/HomePage.vue'
export { default as CardPage } from '../../components/app/Product/CardPage.vue'
export { default as CardTopic } from '../../components/app/Product/CardTopic.vue'
export { default as CarouselsPage } from '../../components/app/Product/CarouselsPage.vue'
export { default as ModalPage } from '../../components/app/Product/ModalPage.vue'
export { default as ProductGroup } from '../../components/app/Product/ProductGroup.vue'
export { default as ShowCase } from '../../components/app/Product/ShowCase.vue'
export { default as TabPage } from '../../components/app/Product/TabPage.vue'
export { default as Slide } from '../../components/app/Slide/Slide.vue'
export { default as Slide2 } from '../../components/app/Slide/Slide2.vue'
export { default as SlideGroup } from '../../components/app/Slide/SlideGroup.vue'
export { default as Slideshow } from '../../components/app/Slide/slideshow.vue'
export { default as SloganPage } from '../../components/app/Slogan/SloganPage.vue'
export { default as TabGroup } from '../../components/app/Tab/TabGroup.vue'
export { default as CustomButton } from '../../components/core/dashboard/CustomButton.vue'
export { default as CustomForm } from '../../components/core/dashboard/CustomForm.vue'
export { default as CustomSelect } from '../../components/core/dashboard/CustomSelect.vue'
export { default as CustomTable } from '../../components/core/dashboard/CustomTable.vue'
export { default as CustomTextbox } from '../../components/core/dashboard/CustomTextbox.vue'
export { default as DrawerMenuItem } from '../../components/core/dashboard/DrawerMenuItem.vue'
export { default as CreateForm } from '../../components/app/Dashboard/Branch/CreateForm.vue'
export { default as EditForm } from '../../components/app/Dashboard/Branch/EditForm.vue'
export { default as AttributeForm } from '../../components/app/Dashboard/Category/AttributeForm.vue'
export { default as DialogBox } from '../../components/app/Dashboard/Category/DialogBox.vue'
export { default as AppBarPage } from '../../components/app/Dashboard/Drawer/AppBarPage.vue'
export { default as NavigationDrawerPage } from '../../components/app/Dashboard/Drawer/NavigationDrawerPage.vue'
export { default as CategorySelect } from '../../components/app/Dashboard/Products/CategorySelect.vue'
export { default as HomePageXs } from '../../components/app/Mobile/Home/HomePageXs.vue'

export const LazyVuetifyLogo = import('../../components/VuetifyLogo.vue' /* webpackChunkName: "components/VuetifyLogo" */).then(c => c.default || c)
export const LazyBestBrands = import('../../components/app/Brands/BestBrands.vue' /* webpackChunkName: "components/app/Brands/BestBrands" */).then(c => c.default || c)
export const LazyBrandAlphabet = import('../../components/app/Brands/BrandAlphabet.vue' /* webpackChunkName: "components/app/Brands/BrandAlphabet" */).then(c => c.default || c)
export const LazyBrandInfo = import('../../components/app/Brands/BrandInfo.vue' /* webpackChunkName: "components/app/Brands/BrandInfo" */).then(c => c.default || c)
export const LazyBrandPagePic = import('../../components/app/Brands/BrandPagePic.vue' /* webpackChunkName: "components/app/Brands/BrandPagePic" */).then(c => c.default || c)
export const LazyPopularBrands = import('../../components/app/Brands/PopularBrands.vue' /* webpackChunkName: "components/app/Brands/PopularBrands" */).then(c => c.default || c)
export const LazySearchBrand = import('../../components/app/Brands/SearchBrand.vue' /* webpackChunkName: "components/app/Brands/SearchBrand" */).then(c => c.default || c)
export const LazyTable = import('../../components/app/Dashboard/Table.vue' /* webpackChunkName: "components/app/Dashboard/Table" */).then(c => c.default || c)
export const LazyFooterPage = import('../../components/app/Footer/FooterPage.vue' /* webpackChunkName: "components/app/Footer/FooterPage" */).then(c => c.default || c)
export const LazyFooterProduct = import('../../components/app/Footer/FooterProduct.vue' /* webpackChunkName: "components/app/Footer/FooterProduct" */).then(c => c.default || c)
export const LazyLogo = import('../../components/app/Header/Logo.vue' /* webpackChunkName: "components/app/Header/Logo" */).then(c => c.default || c)
export const LazyLogo2 = import('../../components/app/Header/Logo2.vue' /* webpackChunkName: "components/app/Header/Logo2" */).then(c => c.default || c)
export const LazyNavPage = import('../../components/app/Header/NavPage.vue' /* webpackChunkName: "components/app/Header/NavPage" */).then(c => c.default || c)
export const LazyNavPage2 = import('../../components/app/Header/NavPage2.vue' /* webpackChunkName: "components/app/Header/NavPage2" */).then(c => c.default || c)
export const LazySubNav = import('../../components/app/Header/SubNav.vue' /* webpackChunkName: "components/app/Header/SubNav" */).then(c => c.default || c)
export const LazyHomePage = import('../../components/app/Home/HomePage.vue' /* webpackChunkName: "components/app/Home/HomePage" */).then(c => c.default || c)
export const LazyCardPage = import('../../components/app/Product/CardPage.vue' /* webpackChunkName: "components/app/Product/CardPage" */).then(c => c.default || c)
export const LazyCardTopic = import('../../components/app/Product/CardTopic.vue' /* webpackChunkName: "components/app/Product/CardTopic" */).then(c => c.default || c)
export const LazyCarouselsPage = import('../../components/app/Product/CarouselsPage.vue' /* webpackChunkName: "components/app/Product/CarouselsPage" */).then(c => c.default || c)
export const LazyModalPage = import('../../components/app/Product/ModalPage.vue' /* webpackChunkName: "components/app/Product/ModalPage" */).then(c => c.default || c)
export const LazyProductGroup = import('../../components/app/Product/ProductGroup.vue' /* webpackChunkName: "components/app/Product/ProductGroup" */).then(c => c.default || c)
export const LazyShowCase = import('../../components/app/Product/ShowCase.vue' /* webpackChunkName: "components/app/Product/ShowCase" */).then(c => c.default || c)
export const LazyTabPage = import('../../components/app/Product/TabPage.vue' /* webpackChunkName: "components/app/Product/TabPage" */).then(c => c.default || c)
export const LazySlide = import('../../components/app/Slide/Slide.vue' /* webpackChunkName: "components/app/Slide/Slide" */).then(c => c.default || c)
export const LazySlide2 = import('../../components/app/Slide/Slide2.vue' /* webpackChunkName: "components/app/Slide/Slide2" */).then(c => c.default || c)
export const LazySlideGroup = import('../../components/app/Slide/SlideGroup.vue' /* webpackChunkName: "components/app/Slide/SlideGroup" */).then(c => c.default || c)
export const LazySlideshow = import('../../components/app/Slide/slideshow.vue' /* webpackChunkName: "components/app/Slide/slideshow" */).then(c => c.default || c)
export const LazySloganPage = import('../../components/app/Slogan/SloganPage.vue' /* webpackChunkName: "components/app/Slogan/SloganPage" */).then(c => c.default || c)
export const LazyTabGroup = import('../../components/app/Tab/TabGroup.vue' /* webpackChunkName: "components/app/Tab/TabGroup" */).then(c => c.default || c)
export const LazyCustomButton = import('../../components/core/dashboard/CustomButton.vue' /* webpackChunkName: "components/core/dashboard/CustomButton" */).then(c => c.default || c)
export const LazyCustomForm = import('../../components/core/dashboard/CustomForm.vue' /* webpackChunkName: "components/core/dashboard/CustomForm" */).then(c => c.default || c)
export const LazyCustomSelect = import('../../components/core/dashboard/CustomSelect.vue' /* webpackChunkName: "components/core/dashboard/CustomSelect" */).then(c => c.default || c)
export const LazyCustomTable = import('../../components/core/dashboard/CustomTable.vue' /* webpackChunkName: "components/core/dashboard/CustomTable" */).then(c => c.default || c)
export const LazyCustomTextbox = import('../../components/core/dashboard/CustomTextbox.vue' /* webpackChunkName: "components/core/dashboard/CustomTextbox" */).then(c => c.default || c)
export const LazyDrawerMenuItem = import('../../components/core/dashboard/DrawerMenuItem.vue' /* webpackChunkName: "components/core/dashboard/DrawerMenuItem" */).then(c => c.default || c)
export const LazyCreateForm = import('../../components/app/Dashboard/Branch/CreateForm.vue' /* webpackChunkName: "components/app/Dashboard/Branch/CreateForm" */).then(c => c.default || c)
export const LazyEditForm = import('../../components/app/Dashboard/Branch/EditForm.vue' /* webpackChunkName: "components/app/Dashboard/Branch/EditForm" */).then(c => c.default || c)
export const LazyAttributeForm = import('../../components/app/Dashboard/Category/AttributeForm.vue' /* webpackChunkName: "components/app/Dashboard/Category/AttributeForm" */).then(c => c.default || c)
export const LazyDialogBox = import('../../components/app/Dashboard/Category/DialogBox.vue' /* webpackChunkName: "components/app/Dashboard/Category/DialogBox" */).then(c => c.default || c)
export const LazyAppBarPage = import('../../components/app/Dashboard/Drawer/AppBarPage.vue' /* webpackChunkName: "components/app/Dashboard/Drawer/AppBarPage" */).then(c => c.default || c)
export const LazyNavigationDrawerPage = import('../../components/app/Dashboard/Drawer/NavigationDrawerPage.vue' /* webpackChunkName: "components/app/Dashboard/Drawer/NavigationDrawerPage" */).then(c => c.default || c)
export const LazyCategorySelect = import('../../components/app/Dashboard/Products/CategorySelect.vue' /* webpackChunkName: "components/app/Dashboard/Products/CategorySelect" */).then(c => c.default || c)
export const LazyHomePageXs = import('../../components/app/Mobile/Home/HomePageXs.vue' /* webpackChunkName: "components/app/Mobile/Home/HomePageXs" */).then(c => c.default || c)
